# Jobs markup demo

A static HTML files for jobs website.